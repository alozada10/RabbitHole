extra_words = ['de', 'la', 'el', 'en', 'no', 'los', 'que', 'las',
               'por', 'es', 'hay', 'se', 'con', 'del', 'para', 'tiene']

lenguage_model = 'es_core_news_sm'

no_hashtag = 'nanhashtag_nullhashtag'
