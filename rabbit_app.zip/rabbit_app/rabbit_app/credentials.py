DJANGO_KEY = 'django-insecure-3!&h-+f#4-^3_eswfe-ap&gbz6f^cdrmi(i1r9u9v5z8rovsp_'

POSTGRES_PASSWORD = 'rabbithole1206533'

POSTGRES_USER = 'rabbit_hole_role'

POSTGRES_HOST = "rabbithole.ckwfizduxg1c.us-east-2.rds.amazonaws.com"

POSTGRES_PORT = 5439

POSTGRES_DATABASE = "postgres"

# Twitter API credentials

access_token = "1054187362765418498-JH1b56VpFsj4tAZwSOluGKgzZ859GN"

access_secret = "i3zD7AMumF0BEKCUpbc9TRZ3pLdxNevEg2CZbYqLpXEyP"

api_key = "EJ60NxIYeHxAgiFd3TY49I714"

api_key_secret = "RSpalfWueKSU3ZcgTDNVVFu7d8W26IT0QK0sc6YZjBhwjm58ud"

bearer_token = "AAAAAAAAAAAAAAAAAAAAABLeDgEAAAAAXYazdH3aAXFIDYstzygbvp0rLVQ" \
               "%3DaSqtxPgSoktNZcrVvfFNcLQ3TdNucLSKmQgV6Lm5Zhm6Uq3ew6 "

